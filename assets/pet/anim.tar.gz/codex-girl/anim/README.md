# 动作对照

每张 `.webp` 是 8 列 × 15 行的 spritesheet：120 帧、640×360、12fps、10 秒完整循环。

文件名的前半是上游的原始动作名，程序按这里的固定英文名找文件，改名会让对应动作用不出来。

| 文件 / File | 上游动作 | English | 何时播放 / When it plays |
|---|---|---|---|
| `idle.webp` | 待机 | Idle breathing | 没有任务在跑 / Nothing is running |
| `thinking.webp` | 思考冒泡 | Thinking | 模型开始回复，还没动工具 / The model is replying, no tool yet |
| `coding.webp` | 写代码 | Coding | 工具执行中 / A tool is running |
| `tool-error.webp` | 没电 | Tool failed | 工具报错 / A tool returned an error |
| `celebrate.webp` | 庆祝 | Celebrate | 一轮正常结束 / A turn finished cleanly |
| `yawn.webp` | 打哈欠 | Yawn | 等待重试或上下文压缩 / Retrying or compacting |
| `sleep.webp` | 睡觉 | Asleep | 长时间没有事件 / No events for a while |
| `click.webp` | 被吓一跳 | Click reply | 宠物被点击 / The pet is clicked |
| `walk.webp` | 奔跑 | Walk | 走动（右行镜像） / Walking (mirrored for the right) |

上游 `codex-girl/media/anim/` 里有 90 个动作，这里只留了上面 9 个：程序只认这 9 个名字，
其余动作没有对应的姿态，装了也不会播。

角色比另外两只桌宠高一头，抽取时按 89.5% 统一缩放并让脚底贴帧底，身材与它们对齐；
画布仍是 5120×5400（8×15 的 640×360 帧），网格与文件名不变。
