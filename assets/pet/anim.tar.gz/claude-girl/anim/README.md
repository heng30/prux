# 动作对照

每张 `.webp` 是 8 列 × 15 行的 spritesheet：120 帧、640×360、12fps、10 秒完整循环。

| 文件 / File | 中文 | English | 何时播放 / When it plays |
|---|---|---|---|
| `idle.webp` | 待机呼吸 | Idle breathing | 没有任务在跑 / Nothing is running |
| `thinking.webp` | 思考冒泡 | Thinking | 模型开始回复，还没动工具 / The model is replying, no tool yet |
| `coding.webp` | 写代码 | Coding | 工具执行中 / A tool is running |
| `tool-error.webp` | 垂头叹气冒汗 | Tool failed | 工具报错 / A tool returned an error |
| `celebrate.webp` | 雀跃庆祝 | Celebrate | 一轮正常结束 / A turn finished cleanly |
| `yawn.webp` | 哈欠连天 | Yawn | 等待重试或上下文压缩 / Retrying or compacting |
| `sleep.webp` | 原地小憩沉眠 | Asleep | 长时间没有事件 / No events for a while |
| `click.webp` | 点击回应-开心跃动 | Click reply | 宠物被点击 / The pet is clicked |
| `walk.webp` | 原地左转奔跑 | Walk | 走动（右行镜像） / Walking (mirrored for the right) |

文件名是固定的：程序按上表的名字找文件，改名会让对应动作用不出来。
